# CineCasa para Android

Esta carpeta es la adaptación Android del proyecto webOS CineCasa 1.0.5. **Un archivo IPK no se convierte renombrándolo a APK**: Android requiere su propio manifiesto, código de aplicación, compilación DEX y firma. Por eso esta versión Android reutiliza el catálogo, las portadas, el HTML, CSS y JavaScript, dentro de una aplicación Android real.

## Qué incluye

- Catálogo CineCasa con las películas y series del proyecto, incluida la ficha de **The Mongoose**.
- Interfaz adaptable a móvil/tablet y navegación por control remoto en Android TV.
- WebView con JavaScript, almacenamiento local y cookies de terceros habilitados para el flujo web normal de los sitios insertados.
- Ventanas emergentes del contenido embebido gestionadas dentro de la app. El contenido externo puede seguir imponiendo sus propios bloqueos o requisitos.
- Reproductor nativo Android basado en AndroidX Media3/ExoPlayer para enlaces directos MP4 y HLS/M3U8 (también se reconoce MPD/DASH).
- Sección **Diagnóstico** con URLs de muestra MP4 y M3U8 y campo para probar un enlace propio.
- El enlace de tipo `embed` de The Mongoose se abre en WebView; no se transforma en un archivo MP4/M3U8 y su funcionamiento depende del proveedor.

## Requisitos para generar el APK

1. Windows, macOS o Linux.
2. Android Studio reciente.
3. JDK 17 (Android Studio incluye una opción de JBR compatible).
4. Android SDK Platform 36 y Android SDK Build-Tools 36 instalados desde SDK Manager.
5. Conexión a Internet durante la primera compilación para descargar Gradle, Android Gradle Plugin y dependencias.

El proyecto configura Android Gradle Plugin 9.5.0, Gradle 9.6.0, `compileSdk/targetSdk 36`, `minSdk 23` y Media3 1.11.1. Las versiones de Media3 y Gradle corresponden a las referencias estables publicadas por Android Developers al 18 de noviembre de 2026.

## Generar un APK de prueba en Windows

1. Descomprime `CineCasa_Android_proyecto.zip`.
2. Abre Android Studio y elige **Open**.
3. Selecciona la carpeta `CineCasaAndroid` (la que contiene `settings.gradle.kts`).
4. En **Tools > SDK Manager**, instala **Android SDK Platform 36** y **Android SDK Build-Tools 36**.
5. Acepta la sincronización de Gradle y espera a que termine la descarga de dependencias.
6. Desde la terminal de Android Studio, ejecuta:

   ```bat
   gradlew.bat :app:assembleDebug
   ```

   También puedes hacer doble clic en `build-apk.bat` si Android SDK está configurado.

7. El APK de depuración quedará en:

   ```text
   app\build\outputs\apk\debug\app-debug.apk
   ```

8. Copia ese APK a tu Android y ábrelo para instalarlo. Puede que Android solicite autorizar la instalación desde esa fuente.

## Generar APK de distribución

En Android Studio: **Build > Generate Signed Bundle / APK > APK**, crea una clave (keystore) propia y guarda una copia segura. No compartas el keystore ni sus contraseñas. El APK debug sirve para pruebas; para distribuir la aplicación usa un APK `release` firmado con tu clave.

## Prueba de reproducción

- La ficha `The Mongoose` mantiene el enlace externo `https://vimeos.net/embed-4y1zr9intkpi.html`. Se abre como página embebida en WebView y la app no elimina anuncios ni intenta eludir restricciones del sitio.
- Las URLs directas MP4/M3U8 y las pruebas de diagnóstico se derivan al reproductor nativo Media3.
- Que un enlace funcione en Android no implica que vaya a funcionar en el navegador de webOS 5; son plataformas y motores distintos.
- No incluye ni aloja el archivo de película de 3 GB. Para reproducir archivos propios, usa URLs que tengas derecho a alojar/distribuir, o un almacenamiento local que la app pueda leer tras añadir un selector de archivos.

## Seguridad y privacidad

La app no tiene cuenta ni servidor propio. Conserva los favoritos y la configuración local del catálogo en el almacenamiento WebView. Los sitios externos que abras dentro de la app pueden recibir cookies y datos propios del navegador, como ocurre al visitarlos normalmente.

## Método alternativo: obtener el APK sin instalar Android Studio (GitHub Actions)

El proyecto incluye el flujo `.github/workflows/build-apk.yml`. GitHub puede compilarlo en la nube y dejar el APK como artefacto descargable. No es necesario instalar Android Studio ni Android SDK en tu PC; sí necesitas una cuenta de GitHub y subir el código a un repositorio.

1. Descomprime `CineCasa_Android_proyecto_GitHub.zip` en tu PC.
2. Entra en [GitHub](https://github.com/) e inicia sesión.
3. Crea un repositorio nuevo, por ejemplo `CineCasa-Android`. Puede ser privado.
4. Sube **todo el contenido** de la carpeta `CineCasaAndroid` al repositorio, incluyendo la carpeta oculta/ocultable `.github` y su archivo `workflows/build-apk.yml`. Puedes hacerlo desde la web de GitHub con **Add file > Upload files**, o mediante GitHub Desktop.
5. Confirma los archivos con **Commit changes** en la rama `main`.
6. Abre la pestaña **Actions** del repositorio. El flujo **Construir APK de CineCasa** debería iniciarse tras el commit. También puedes abrirlo y pulsar **Run workflow**.
7. Cuando el trabajo termine con una marca verde, abre esa ejecución y baja hasta **Artifacts**.
8. Descarga `CineCasa-Android-debug-APK.zip`, descomprímelo y encontrarás `app-debug.apk`.
9. Pasa `app-debug.apk` a tu teléfono Android e instálalo. Puede que Android te pida permitir instalaciones desde esa fuente.

El flujo utiliza Java 17, Android SDK 36, Android Gradle Plugin 9.5.0 y Gradle 9.6.0; son versiones alineadas con la tabla de compatibilidad oficial de AGP 9.5.0. Usa Gradle instalado por la acción de GitHub, así que no depende del `gradle-wrapper.jar` local. Las acciones de GitHub instalan Java/SDK, preparan Gradle y publican el APK como artefacto. Consulta la documentación de [AGP](https://developer.android.com/build/releases/about-agp) y [Gradle en GitHub Actions](https://docs.gradle.org/current/userguide/github-actions.html).

**Importante:** el archivo resultante es un APK `debug` para pruebas, no un APK `release` firmado para distribución pública. No publiques claves ni contraseñas en el repositorio. El proyecto no contiene la película de 3 GB; solo conserva los enlaces del catálogo.
