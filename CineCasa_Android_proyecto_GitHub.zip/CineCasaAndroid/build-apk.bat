@echo off
setlocal
call "%~dp0gradlew.bat" :app:assembleDebug
if errorlevel 1 (
  echo.
  echo No se pudo compilar. Verifica que Android Studio y Android SDK Platform 36 esten instalados.
  exit /b 1
)
echo.
echo APK generado en:
echo %~dp0app\build\outputs\apk\debug\app-debug.apk
