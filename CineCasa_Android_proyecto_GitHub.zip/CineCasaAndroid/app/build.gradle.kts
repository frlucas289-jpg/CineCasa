plugins {
    id("com.android.application")
}

android {
    namespace = "com.cinecasa.android"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.cinecasa.android"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0"

        // El mismo paquete funciona en móviles, tablets y Android TV.
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.17.0")
    implementation("androidx.media3:media3-exoplayer:1.11.1")
    implementation("androidx.media3:media3-exoplayer-hls:1.11.1")
    implementation("androidx.media3:media3-ui:1.11.1")
}
