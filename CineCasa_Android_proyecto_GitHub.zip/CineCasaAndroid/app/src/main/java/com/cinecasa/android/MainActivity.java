package com.cinecasa.android;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
    private static final String APP_ASSET_HOST = "appassets.androidplatform.net";
    private static final String START_URL = "https://" + APP_ASSET_HOST + "/assets/web/index.html";

    private FrameLayout root;
    private WebView webView;
    private WebView popupWebView;
    private Dialog popupDialog;
    private View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;
    private FrameLayout fullscreenContainer;
    private int normalSystemUi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        normalSystemUi = getWindow().getDecorView().getSystemUiVisibility();
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8, 10, 16));
        setContentView(root);

        webView = new WebView(this);
        configureWebView(webView);
        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                // HTTPS/HTTP links remain inside the WebView so that embedded providers,
                // consent screens and their ordinary ad flow can work as they do in a browser.
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)
                        || "about".equalsIgnoreCase(scheme));
            }
        });
        webView.addJavascriptInterface(new CineCasaBridge(), "CineCasaAndroid");
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        webView.loadUrl(START_URL);
    }

    private void configureWebView(WebView target) {
        WebSettings settings = target.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        target.setBackgroundColor(Color.rgb(8, 10, 16));
        target.setOverScrollMode(View.OVER_SCROLL_NEVER);
        target.setFocusable(true);
        target.setFocusableInTouchMode(true);
        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(target, true);
    }

    private final class CineCasaBridge {
        @JavascriptInterface
        public void playVideo(String url, String title) {
            if (!isHttpUrl(url)) return;
            runOnUiThread(() -> {
                Intent intent = new Intent(MainActivity.this, NativePlayerActivity.class);
                intent.putExtra(NativePlayerActivity.EXTRA_URL, url);
                intent.putExtra(NativePlayerActivity.EXTRA_TITLE,
                        title == null || title.trim().isEmpty() ? "CineCasa" : title);
                startActivity(intent);
            });
        }

        @JavascriptInterface
        public void openExternal(String url) {
            if (!isHttpUrl(url)) return;
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                try {
                    startActivity(intent);
                } catch (Exception ignored) {
                    // Leave the user in CineCasa when no browser can handle the URL.
                }
            });
        }

        @JavascriptInterface
        public String platform() {
            return "Android";
        }
    }

    private boolean isHttpUrl(String value) {
        if (value == null) return false;
        Uri uri = Uri.parse(value.trim());
        String scheme = uri.getScheme();
        return uri.isHierarchical() && uri.getHost() != null
                && ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
    }

    private final class CineCasaChromeClient extends WebChromeClient {
        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            showPopupWindow(resultMsg);
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (fullscreenView != null) {
                callback.onCustomViewHidden();
                return;
            }
            fullscreenView = view;
            fullscreenCallback = callback;
            webView.setVisibility(View.GONE);
            if (fullscreenContainer == null) {
                fullscreenContainer = new FrameLayout(MainActivity.this);
                fullscreenContainer.setBackgroundColor(Color.BLACK);
                root.addView(fullscreenContainer, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            }
            fullscreenContainer.setVisibility(View.VISIBLE);
            fullscreenContainer.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        }

        @Override
        public void onHideCustomView() {
            if (fullscreenView == null) return;
            fullscreenContainer.removeView(fullscreenView);
            fullscreenContainer.setVisibility(View.GONE);
            fullscreenView = null;
            webView.setVisibility(View.VISIBLE);
            getWindow().getDecorView().setSystemUiVisibility(normalSystemUi);
            if (fullscreenCallback != null) fullscreenCallback.onCustomViewHidden();
            fullscreenCallback = null;
        }

        @Override
        public void onCloseWindow(WebView window) {
            closePopupWindow();
        }
    }

    private void showPopupWindow(Message resultMsg) {
        if (popupDialog != null && popupDialog.isShowing()) {
            closePopupWindow();
        }
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);
        shell.setBackgroundColor(Color.rgb(8, 10, 16));

        Button close = new Button(this);
        close.setText("Cerrar ventana emergente");
        close.setAllCaps(false);
        close.setTextColor(Color.WHITE);
        close.setBackgroundColor(Color.rgb(35, 40, 52));
        shell.addView(close, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        popupWebView = new WebView(this);
        configureWebView(popupWebView);
        popupWebView.setWebViewClient(new WebViewClient());
        popupWebView.setWebChromeClient(new CineCasaChromeClient());
        shell.addView(popupWebView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        popupDialog = new Dialog(this);
        popupDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        popupDialog.setContentView(shell);
        Window window = popupDialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.BLACK));
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            window.setGravity(Gravity.CENTER);
            window.addFlags(WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED);
        }
        close.setOnClickListener(v -> closePopupWindow());
        popupDialog.setOnDismissListener(dialog -> {
            if (popupWebView != null) {
                popupWebView.stopLoading();
                popupWebView.destroy();
                popupWebView = null;
            }
        });
        popupDialog.show();
        if (window != null) window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);

        WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
        transport.setWebView(popupWebView);
        resultMsg.sendToTarget();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void closePopupWindow() {
        if (popupDialog != null && popupDialog.isShowing()) popupDialog.dismiss();
        popupDialog = null;
    }

    @Override
    public void onBackPressed() {
        if (fullscreenView != null) {
            new CineCasaChromeClient().onHideCustomView();
            return;
        }
        if (popupDialog != null && popupDialog.isShowing()) {
            closePopupWindow();
            return;
        }
        if (webView != null) {
            webView.evaluateJavascript(
                    "document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',keyCode:27,which:27,bubbles:true}));",
                    null);
            return;
        }
        super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.removeJavascriptInterface("CineCasaAndroid");
            webView.destroy();
            webView = null;
        }
        if (popupDialog != null) closePopupWindow();
        super.onDestroy();
    }
}
