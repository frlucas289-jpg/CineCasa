package com.cinecasa.android;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.Util;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import android.net.Uri;

public class NativePlayerActivity extends Activity {
    public static final String EXTRA_URL = "cinecasa.extra.URL";
    public static final String EXTRA_TITLE = "cinecasa.extra.TITLE";

    private ExoPlayer player;
    private PlayerView playerView;
    private TextView statusView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        String url = getIntent().getStringExtra(EXTRA_URL);
        String title = getIntent().getStringExtra(EXTRA_TITLE);
        if (url == null || !(url.startsWith("https://") || url.startsWith("http://"))) {
            finish();
            return;
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(12), dp(6), dp(12), dp(6));
        header.setBackgroundColor(Color.rgb(14, 16, 22));

        Button back = new Button(this);
        back.setText("‹ Volver");
        back.setAllCaps(false);
        back.setTextColor(Color.WHITE);
        back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(100), dp(48)));

        TextView titleView = new TextView(this);
        titleView.setText(title == null ? "CineCasa" : title);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(18);
        titleView.setGravity(Gravity.CENTER_VERTICAL);
        titleView.setPadding(dp(14), 0, dp(8), 0);
        header.addView(titleView, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(header, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(58)));

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        root.addView(playerView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        statusView = new TextView(this);
        statusView.setTextColor(Color.LTGRAY);
        statusView.setTextSize(14);
        statusView.setPadding(dp(14), dp(8), dp(14), dp(8));
        statusView.setVisibility(View.GONE);
        root.addView(statusView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        initializePlayer(url);
    }

    private void initializePlayer(String url) {
        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                .setUserAgent(Util.getUserAgent(this, "CineCasa"))
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000);
        DefaultDataSource.Factory dataSourceFactory = new DefaultDataSource.Factory(this, httpFactory);
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(dataSourceFactory);

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(mediaSourceFactory)
                .build();
        playerView.setPlayer(player);

        String lower = url.toLowerCase();
        MediaItem.Builder itemBuilder = new MediaItem.Builder().setUri(Uri.parse(url));
        if (lower.contains(".m3u8")) {
            itemBuilder.setMimeType(MimeTypes.APPLICATION_M3U8);
        } else if (lower.contains(".mpd")) {
            itemBuilder.setMimeType(MimeTypes.APPLICATION_MPD);
        } else if (lower.contains(".mp4")) {
            itemBuilder.setMimeType(MimeTypes.VIDEO_MP4);
        }

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_BUFFERING) {
                    statusView.setVisibility(View.VISIBLE);
                    statusView.setText("Cargando vídeo…");
                } else if (playbackState == Player.STATE_READY) {
                    statusView.setVisibility(View.GONE);
                } else if (playbackState == Player.STATE_ENDED) {
                    statusView.setVisibility(View.VISIBLE);
                    statusView.setText("Reproducción finalizada.");
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                statusView.setVisibility(View.VISIBLE);
                statusView.setText("No se pudo reproducir este enlace. Código: "
                        + error.errorCodeName + "\n" + safeMessage(error.getMessage())
                        + "\nComprueba que la URL sea un MP4 o M3U8 accesible y compatible.");
            }
        });
        player.setMediaItem(itemBuilder.build());
        player.prepare();
        player.play();
    }

    private String safeMessage(String message) {
        return message == null ? "Error de reproducción." : message;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) {
            player.release();
            player = null;
        }
        if (playerView != null) playerView.setPlayer(null);
    }
}
