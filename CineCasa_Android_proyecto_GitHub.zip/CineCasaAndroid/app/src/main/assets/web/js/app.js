(function () {
  'use strict';
  var state = { catalog: { items: [] }, view: 'home', selected: null, searchOpen: false, searchQuery: '', playerItem: null };
  var main = document.getElementById('mainView');
  var searchPanel = document.getElementById('searchPanel');
  var settingsPanel = document.getElementById('settingsPanel');
  var playerPanel = document.getElementById('playerPanel');
  var video = document.getElementById('videoPlayer');
  var embedFrame = document.getElementById('embedPlayer');
  var favoritesKey = 'cinecasa_favorites';
  var sourceKey = 'cinecasa_catalog_url';
  var favorites = loadFavorites();
  var toastTimer = null;

  function loadFavorites() { try { return JSON.parse(localStorage.getItem(favoritesKey) || '[]'); } catch (e) { return []; } }
  function saveFavorites() { try { localStorage.setItem(favoritesKey, JSON.stringify(favorites)); } catch (e) {} }
  function escapeHtml(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, function (c) { return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function safeImage(src) { if (!src) return ''; if (/^(https?:\/\/|assets\/)/i.test(src)) return src; return ''; }
  function validMediaUrl(url) { return /^https?:\/\//i.test(String(url || '').trim()); }
  function itemList() { return Array.isArray(state.catalog.items) ? state.catalog.items : []; }
  function getItem(id) { var all=itemList(); for(var i=0;i<all.length;i++){if(all[i].id===id)return all[i];} return null; }
  function showToast(message) { var el=document.getElementById('toast'); el.textContent=message; el.classList.remove('hidden'); clearTimeout(toastTimer); toastTimer=setTimeout(function(){el.classList.add('hidden');},3600); }
  function setActiveNav(view) { var nodes=document.querySelectorAll('.nav-btn'); for(var i=0;i<nodes.length;i++){nodes[i].classList.toggle('active',nodes[i].getAttribute('data-view')===view);} }
  function card(item) {
    var poster=safeImage(item.poster);
    var meta=[item.year,item.genre].filter(Boolean).join(' · ');
    var art=poster ? '<img src="'+escapeHtml(poster)+'" alt="Portada de '+escapeHtml(item.title)+'" onerror="this.style.display=\'none\';this.parentNode.className+=\' poster-failed\';">' : '<div class="poster-placeholder">'+escapeHtml(item.title)+'</div>';
    return '<button class="movie-card" data-item="'+escapeHtml(item.id)+'" tabindex="0" aria-label="Abrir '+escapeHtml(item.title)+'"><div class="poster-wrap">'+art+'</div><span class="card-title">'+escapeHtml(item.title)+'</span><span class="card-meta">'+escapeHtml(meta || (item.type==='series'?'Serie':'Película'))+'</span></button>';
  }
  function section(title, items, note) {
    if (!items.length) return '';
    var out='<section class="content-section"><div class="section-head"><h2>'+escapeHtml(title)+'</h2><span>'+escapeHtml(note || '')+'</span></div><div class="movie-row">';
    for(var i=0;i<items.length;i++) out+=card(items[i]);
    return out+'</div></section>';
  }
  function renderHome() {
    var items=itemList();
    if(!items.length){main.innerHTML='<div class="empty-state"><h2>Tu catálogo está vacío</h2><p>Agrega películas o series en el panel de administración e importa el archivo JSON.</p></div>';return;}
    var featured=null;
    for(var i=0;i<items.length;i++){if(items[i].homeFeatured){featured=items[i];break;}}
    if(!featured){for(var j=0;j<items.length;j++){if(items[j].featured){featured=items[j];break;}}}
    if(!featured)featured=items[0];
    var movies=items.filter(function(x){return x.type==='movie';});
    var series=items.filter(function(x){return x.type==='series';});
    var badge=featured.homeFeatured?'NOVEDAD EN CINECASA':(featured.demo?'CONTENIDO DE DEMOSTRACIÓN':'CATÁLOGO PERSONAL');
    var poster=safeImage(featured.backdrop || featured.poster);
    var heroPoster=poster?'<button class="hero-poster-button" data-item="'+escapeHtml(featured.id)+'" aria-label="Ver detalles de '+escapeHtml(featured.title)+'"><img class="hero-poster" src="'+escapeHtml(poster)+'" alt="Portada de '+escapeHtml(featured.title)+'" onerror="this.style.display=\'none\';this.parentNode.classList.add(\'poster-failed\');"><span class="hero-poster-fallback">'+escapeHtml(featured.title)+'</span></button>':'';
    var playAction=(featured.type==='movie' && validMediaUrl(featured.url))?'<button class="primary-btn" data-play="'+escapeHtml(featured.id)+'">▶ &nbsp; PLAY</button>':'<button class="primary-btn" data-item="'+escapeHtml(featured.id)+'">▶ &nbsp; Ver detalles</button>';
    main.innerHTML='<section class="hero"><div class="hero-content"><p class="eyebrow">CINECASA · CATÁLOGO PERSONAL</p><div class="badge-demo">'+escapeHtml(badge)+'</div><h1>'+escapeHtml(featured.title)+'</h1><div class="meta-row"><span>'+escapeHtml(featured.year || '—')+'</span><span class="meta-pill">'+escapeHtml(featured.rating || 'CATÁLOGO')+'</span><span>'+escapeHtml(featured.genre || (featured.type==='series'?'Serie':'Película'))+'</span></div><p class="hero-description">'+escapeHtml(featured.description || 'Explora tu catálogo personal de películas y series.')+'</p><div class="hero-actions">'+playAction+'<button class="secondary-btn" data-item="'+escapeHtml(featured.id)+'">Ver detalles</button><button class="secondary-btn" data-action="browse">Explorar catálogo</button></div></div>'+heroPoster+'</section>'+section('Películas para descubrir',movies.slice(0,5),'Tu colección')+section('Series',series.slice(0,5),'Temporadas y episodios')+'<div class="footer-note">CineCasa · Las fichas de demostración son ejemplos editables. Usa enlaces de reproducción que tengas autorización para utilizar.</div>';
    setActiveNav('home');
  }
  function renderListing(type) {
    var all=itemList().filter(function(x){return type==='favorites'?favorites.indexOf(x.id)!==-1:x.type===type;});
    var title=type==='movie'?'Películas':type==='series'?'Series':'Mi lista';
    main.innerHTML='<div class="page-heading"><h1>'+title+'</h1><p>'+ (type==='favorites'?'Tus títulos guardados.':'Explora el catálogo completo.')+'</p></div>'+(all.length?'<section class="content-section"><div class="movie-row">'+all.map(card).join('')+'</div></section>':'<div class="empty-state"><h2>'+(type==='favorites'?'Todavía no guardaste títulos':'No hay contenido todavía')+'</h2><p>'+(type==='favorites'?'Abre una película o serie y elige “Mi lista”.':'Agrega contenido desde el panel de administración.')+'</p></div>');
    setActiveNav(type==='favorites'?'favorites':type==='movie'?'movies':'series');
  }
  function renderDetails(item) {
    state.view='details';state.selected=item;
    var isSeries=item.type==='series'; var episodes='';
    if(isSeries){var seasons=Array.isArray(item.seasons)?item.seasons:[]; for(var s=0;s<seasons.length;s++){episodes+='<div class="section-head" style="margin-top:22px"><h2>'+escapeHtml(seasons[s].name || ('Temporada '+(s+1)))+'</h2></div><div class="episode-list">';var eps=seasons[s].episodes||[];for(var e=0;e<eps.length;e++){var ep=eps[e];episodes+='<button class="episode-btn" data-episode-item="'+escapeHtml(item.id)+'" data-season="'+s+'" data-episode="'+e+'"><span><b>'+escapeHtml(ep.number || e+1)+'. '+escapeHtml(ep.title || 'Episodio')+'</b><br><small>'+escapeHtml(ep.duration || '')+'</small></span><span>▶</span></button>';}episodes+='</div>';}}
    var inFav=favorites.indexOf(item.id)!==-1;
    var meta=[item.year,item.genre,item.rating,item.duration].filter(Boolean).join('　·　');
    var poster=safeImage(item.backdrop || item.poster);
    main.innerHTML='<section class="detail-hero" style="'+(poster?'background-image:linear-gradient(90deg,#080a10 0%,rgba(8,10,16,.91) 36%,rgba(8,10,16,.38) 100%),linear-gradient(0deg,#080a10 0%,transparent 75%),url(\''+escapeHtml(poster)+'\');background-size:cover;background-position:center;':'')+'"><div class="detail-content"><p class="eyebrow">'+(isSeries?'SERIE':'PELÍCULA')+' · CINECASA</p><h1>'+escapeHtml(item.title)+'</h1><div class="meta-row">'+escapeHtml(meta)+'</div><p class="hero-description">'+escapeHtml(item.description || '')+'</p><div class="hero-actions">'+(isSeries?'':'<button class="primary-btn" data-play="'+escapeHtml(item.id)+'">▶ &nbsp; PLAY</button>')+'<button class="secondary-btn" data-favorite="'+escapeHtml(item.id)+'">'+(inFav?'✓ En mi lista':'＋ Mi lista')+'</button><button class="secondary-btn" data-action="back-list">‹ Volver</button></div>'+ (item.demo?'':'')+'</div></section><section class="content-section">'+(isSeries?episodes:'<div class="muted">Selecciona PLAY para reproducir el enlace asociado a esta película.</div>')+'</section>';
    focusFirst();
  }
  function renderDiagnostics() {
    main.innerHTML = '<div class="page-heading"><h1>Diagnóstico de reproducción</h1><p>Prueba MP4 y HLS/M3U8 en este dispositivo con el reproductor nativo de Android.</p></div>' +
      '<section class="content-section"><div class="diagnostic-grid">' +
      '<article class="diagnostic-card"><h2>Prueba MP4</h2><p>Vídeo de demostración H.264. Se abrirá en el reproductor nativo cuando esté disponible.</p><button class="primary-btn" data-diagnostic-url="https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" data-diagnostic-title="Prueba MP4">Probar MP4</button></article>' +
      '<article class="diagnostic-card"><h2>Prueba HLS / M3U8</h2><p>Flujo HLS de prueba. La disponibilidad depende de la conexión y del servidor.</p><button class="primary-btn" data-diagnostic-url="https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8" data-diagnostic-title="Prueba HLS">Probar M3U8</button></article>' +
      '</div><div class="diagnostic-card diagnostic-custom"><h2>Probar mi propio enlace</h2><label for="diagnosticUrlInput">URL MP4 o M3U8</label><input id="diagnosticUrlInput" class="text-field" type="url" placeholder="https://servidor/archivo.mp4"><button class="secondary-btn" data-diagnostic-custom="1">Probar enlace</button></div>' +
      '<div class="diagnostic-card"><h2>Informe del dispositivo</h2><textarea id="diagnosticReport" class="diagnostic-report" readonly></textarea><button class="secondary-btn" data-diagnostic-copy="1">Copiar informe</button></div>' +
      '<p class="tiny muted">Nota: esta prueba valida el reproductor MP4/HLS. No garantiza que una página externa con reproductor incrustado sea compatible.</p></section>';
    var report = [
      'CineCasa Android - diagnóstico',
      'Fecha: ' + new Date().toISOString(),
      'Plataforma: ' + (window.CineCasaAndroid && window.CineCasaAndroid.platform ? window.CineCasaAndroid.platform() : 'Navegador web'),
      'Agente: ' + navigator.userAgent,
      'Pruebas: MP4 y HLS se ejecutan por separado; anotar si se ve imagen, hay audio o aparece un error.'
    ].join('\n');
    var reportField = document.getElementById('diagnosticReport');
    if (reportField) reportField.value = report;
    setActiveNav('diagnostics');
  }
  function runDiagnostic(url, title) {
    if (!validMediaUrl(url)) { showToast('Introduce una dirección HTTP o HTTPS válida.'); return; }
    var reportField = document.getElementById('diagnosticReport');
    if (reportField) reportField.value += '\n\nPrueba iniciada: ' + title + '\nURL: ' + url + '\nResultado: pendiente de comprobar en pantalla.';
    startPlayback({ id: 'diagnostic-' + Date.now(), title: title, type: 'movie', url: url, urlType: 'direct' }, null);
  }
  function navigate(view) { state.view=view; state.selected=null; if(view==='home')renderHome(); else if(view==='movies')renderListing('movie'); else if(view==='series')renderListing('series'); else if(view==='favorites')renderListing('favorites'); else if(view==='diagnostics')renderDiagnostics(); focusFirst(); }
  function searchRender(query) {
    var q=String(query||'').toLowerCase().trim(); var results=itemList().filter(function(x){return !q || (x.title+' '+(x.genre||'')+' '+(x.description||'')).toLowerCase().indexOf(q)!==-1;});
    document.getElementById('searchResults').innerHTML=results.length?results.map(card).join(''):'<div class="empty-state"><h2>Sin resultados</h2><p>Prueba con otro título o género.</p></div>';
  }
  function openSearch() { searchPanel.classList.remove('hidden'); document.getElementById('searchInput').value=''; searchRender(''); setTimeout(function(){document.getElementById('searchInput').focus();},100); }
  function closeSearch() { searchPanel.classList.add('hidden'); focusFirst(); }
  function openSettings() { document.getElementById('catalogUrlInput').value=localStorage.getItem(sourceKey)||((window.CINE_CONFIG&&window.CINE_CONFIG.catalogUrl)||''); document.getElementById('settingsMessage').textContent=''; settingsPanel.classList.remove('hidden'); setTimeout(function(){document.getElementById('catalogUrlInput').focus();},100); }
  function closeSettings() { settingsPanel.classList.add('hidden'); focusFirst(); }
  function mergeHomeFeatured(remoteData, bundledData) {
    var merged=remoteData && Array.isArray(remoteData.items)?remoteData:{items:[]};
    var items=merged.items.slice();
    var bundled=bundledData && Array.isArray(bundledData.items)?bundledData.items:[];
    for(var i=0;i<bundled.length;i++){
      var candidate=bundled[i];
      if(!candidate.homeFeatured)continue;
      var found=-1;
      for(var j=0;j<items.length;j++){if(items[j].id===candidate.id){found=j;break;}}
      if(found===-1)items.unshift(candidate);
      else items[found]=Object.assign({},items[found],candidate);
    }
    merged.items=items;
    return merged;
  }
  function bundledCatalog() {
    var source = window.CINE_BUNDLED_CATALOG;
    if (source && Array.isArray(source.items)) return JSON.parse(JSON.stringify(source));
    return { schemaVersion: 1, items: [{
      id: 'the-mongoose-2026', title: 'The Mongoose', type: 'movie', year: '2026',
      genre: 'Acción · Thriller', description: 'Película añadida al catálogo CineCasa.',
      poster: 'assets/covers/the-mongoose-poster.jpg', backdrop: 'assets/covers/the-mongoose-poster.jpg',
      featured: true, homeFeatured: true, url: 'https://vimeos.net/embed-4y1zr9intkpi.html', urlType: 'embed'
    }] };
  }
  function fetchCatalog(path) {
    return new Promise(function(resolve, reject) {
      if (window.fetch) {
        window.fetch(path, { cache: 'no-store' }).then(function(r) {
          if (!r.ok) throw new Error('HTTP ' + r.status + ' al cargar ' + path);
          return r.json();
        }).then(function(data) {
          if (!data || !Array.isArray(data.items)) throw new Error('El JSON no contiene un array "items".');
          resolve(data);
        }).catch(reject);
        return;
      }
      var xhr = new XMLHttpRequest();
      xhr.open('GET', path, true);
      xhr.onreadystatechange = function() {
        if (xhr.readyState !== 4) return;
        if (xhr.status < 200 || xhr.status >= 300) { reject(new Error('HTTP ' + xhr.status + ' al cargar ' + path)); return; }
        try {
          var data = JSON.parse(xhr.responseText);
          if (!data || !Array.isArray(data.items)) throw new Error('El JSON no contiene un array "items".');
          resolve(data);
        } catch (e) { reject(e); }
      };
      xhr.onerror = function() { reject(new Error('No se pudo conectar con ' + path)); };
      xhr.send();
    });
  }
  function loadCatalog(url) {
    var local = bundledCatalog();
    if (!url || url === 'data/catalog.json') {
      state.catalog = local;
      renderHome();
      return Promise.resolve(true);
    }
    return fetchCatalog(url).then(function(remote) {
      state.catalog = mergeHomeFeatured(remote, local);
      renderHome();
      return true;
    }).catch(function(err) {
      // Never leave the TV with an empty screen when a saved remote catalog is offline.
      state.catalog = local;
      renderHome();
      throw err;
    });
  }
  function saveRemoteCatalog() {
    var val=document.getElementById('catalogUrlInput').value.trim();
    if(val && !validMediaUrl(val)){document.getElementById('settingsMessage').textContent='Introduce una URL que comience con https:// o http://';return;}
    if(val)localStorage.setItem(sourceKey,val);else localStorage.removeItem(sourceKey);
    var label=document.getElementById('settingsMessage');label.textContent='Cargando catálogo…';
    loadCatalog(val||'data/catalog.json').then(function(){label.textContent='Catálogo cargado correctamente.';showToast('Catálogo actualizado');setTimeout(closeSettings,700);}).catch(function(err){label.textContent='No se pudo cargar: '+err.message;});
  }
  function toggleFavorite(id) { var idx=favorites.indexOf(id);if(idx===-1)favorites.push(id);else favorites.splice(idx,1);saveFavorites();var item=getItem(id);if(state.view==='details'&&item)renderDetails(item);else if(state.view==='favorites')renderListing('favorites');showToast(idx===-1?'Agregado a Mi lista':'Quitado de Mi lista'); }
  function startPlayback(item, episode) {
    var url=episode?episode.url:item.url;
    var urlType=episode?'direct':(item.urlType||'direct');
    if(!validMediaUrl(url)){showToast('Esta ficha todavía no tiene una URL de reproducción válida.');return;}
    if(urlType!=='embed' && window.CineCasaAndroid && typeof window.CineCasaAndroid.playVideo==='function'){
      window.CineCasaAndroid.playVideo(url, item.title+(episode?' · '+(episode.title||'Episodio'):''));
      return;
    }
    state.playerItem=item;
    document.getElementById('playerTitle').textContent=item.title+(episode?' · '+(episode.title||'Episodio'):'');
    var error=document.getElementById('playerError');error.classList.add('hidden');error.textContent='';
    var playerFoot=document.getElementById('playerFoot');
    playerFoot.textContent='Usa los controles del reproductor del televisor. Pulsa BACK para salir.';
    video.pause();video.removeAttribute('src');while(video.firstChild)video.removeChild(video.firstChild);video.classList.add('hidden');
    embedFrame.classList.add('hidden');embedFrame.removeAttribute('src');
    playerPanel.classList.remove('hidden');
    if(urlType==='embed'){
      embedFrame.src=url;
      embedFrame.classList.remove('hidden');
      playerFoot.textContent='Reproductor externo: usa las flechas y OK. Si no carga, el proveedor puede bloquear la inserción en webOS. Pulsa Volver para salir.';
      return;
    }
    var source=document.createElement('source');source.src=url;
    if(/\.m3u8(\?|$)/i.test(url))source.type='application/vnd.apple.mpegurl';else if(/\.mp4(\?|$)/i.test(url))source.type='video/mp4';
    video.appendChild(source);video.classList.remove('hidden');
    try{video.load();var p=video.play();if(p&&p.catch)p.catch(function(){showPlayerError('El televisor no pudo iniciar la reproducción automáticamente. Pulsa PLAY en los controles. Revisa también que el enlace sea un archivo MP4 o una lista HLS (.m3u8) accesible.');});}catch(e){showPlayerError('No se pudo iniciar el vídeo. Comprueba el formato y el enlace.');}
  }
  function showPlayerError(message){var el=document.getElementById('playerError');el.textContent=message;el.classList.remove('hidden');}
  function stopPlayback(){video.pause();video.removeAttribute('src');while(video.firstChild)video.removeChild(video.firstChild);video.load();embedFrame.removeAttribute('src');embedFrame.classList.add('hidden');video.classList.remove('hidden');playerPanel.classList.add('hidden');if(state.selected)renderDetails(state.selected);else navigate(state.view==='details'?'home':state.view);}
  video.addEventListener('error',function(){showPlayerError('No se pudo reproducir este enlace. Usa una URL directa MP4 o HLS (.m3u8) y comprueba el códec de vídeo/audio.');});
  video.addEventListener('ended',function(){showToast('Reproducción finalizada');});
  function focusables(){return Array.prototype.slice.call(document.querySelectorAll('button:not([disabled]),input:not([disabled]),.brand[tabindex="0"],[tabindex="0"]')).filter(function(el){return !!(el.offsetWidth||el.offsetHeight||el.getClientRects().length)&&!el.closest('.hidden');});}
  function focusFirst(){setTimeout(function(){var el=main.querySelector('button.movie-card,button.primary-btn,button.nav-btn');if(el)el.focus();else{var all=focusables();if(all.length)all[0].focus();}},50);}
  function moveFocus(key){var active=document.activeElement;var list=focusables();if(!list.length)return;var r=active&&active.getBoundingClientRect?active.getBoundingClientRect():null;if(!r||!active||list.indexOf(active)<0){list[0].focus();return;}var cx=r.left+r.width/2,cy=r.top+r.height/2;var best=null,bestScore=Infinity;
    for(var i=0;i<list.length;i++){var el=list[i];if(el===active)continue;var q=el.getBoundingClientRect(),x=q.left+q.width/2,y=q.top+q.height/2,dx=x-cx,dy=y-cy,primary,secondary;if(key==='ArrowRight'){if(dx<=5)continue;primary=dx;secondary=Math.abs(dy);}else if(key==='ArrowLeft'){if(dx>=-5)continue;primary=-dx;secondary=Math.abs(dy);}else if(key==='ArrowDown'){if(dy<=5)continue;primary=dy;secondary=Math.abs(dx);}else{if(dy>=-5)continue;primary=-dy;secondary=Math.abs(dx);}var score=primary+secondary*2.2;if(score<bestScore){bestScore=score;best=el;}}
    if(best){best.focus();try{best.scrollIntoView({block:'nearest',inline:'nearest'});}catch(e){}}
  }
  document.addEventListener('keydown',function(e){var k=e.key||'';var code=e.keyCode||e.which;
    if(playerPanel.classList.contains('hidden')===false){if(k==='Escape'||k==='Backspace'||code===461||code===27){e.preventDefault();stopPlayback();}return;}
    if(!searchPanel.classList.contains('hidden')){if(k==='Escape'||code===461){e.preventDefault();closeSearch();}return;}
    if(!settingsPanel.classList.contains('hidden')){if(k==='Escape'||code===461){e.preventDefault();closeSettings();}return;}
    if(k==='ArrowLeft'||k==='ArrowRight'||k==='ArrowUp'||k==='ArrowDown'){e.preventDefault();moveFocus(k);}
    else if(k==='Escape'||code===461){e.preventDefault();if(state.view==='details')navigate('home');else navigate('home');}
    else if(k==='/' && !e.target.matches('input')){e.preventDefault();openSearch();}
  });
  document.addEventListener('click',function(e){
    var diagnostic=e.target.closest('[data-diagnostic-url]');if(diagnostic){runDiagnostic(diagnostic.getAttribute('data-diagnostic-url'),diagnostic.getAttribute('data-diagnostic-title')||'Prueba');return;}
    var diagnosticCustom=e.target.closest('[data-diagnostic-custom]');if(diagnosticCustom){var customInput=document.getElementById('diagnosticUrlInput');runDiagnostic(customInput?customInput.value.trim():'','Prueba personalizada');return;}
    var diagnosticCopy=e.target.closest('[data-diagnostic-copy]');if(diagnosticCopy){var report=document.getElementById('diagnosticReport');if(report){report.focus();report.select();try{document.execCommand('copy');showToast('Informe copiado');}catch(err){showToast('Selecciona y copia el informe manualmente.');}}return;}
    var nav=e.target.closest('[data-view]');if(nav){navigate(nav.getAttribute('data-view'));return;}
    var itemBtn=e.target.closest('[data-item]');if(itemBtn){var item=getItem(itemBtn.getAttribute('data-item'));if(item)renderDetails(item);return;}
    var play=e.target.closest('[data-play]');if(play){var item2=getItem(play.getAttribute('data-play'));if(item2)startPlayback(item2,null);return;}
    var ep=e.target.closest('[data-episode-item]');if(ep){var it=getItem(ep.getAttribute('data-episode-item'));if(it){var s=Number(ep.getAttribute('data-season')),n=Number(ep.getAttribute('data-episode'));var season=it.seasons&&it.seasons[s];var episode=season&&season.episodes&&season.episodes[n];if(episode)startPlayback(it,episode);}return;}
    var fav=e.target.closest('[data-favorite]');if(fav){toggleFavorite(fav.getAttribute('data-favorite'));return;}
    var action=e.target.closest('[data-action]');if(action){var act=action.getAttribute('data-action');if(act==='home'||act==='browse')navigate('home');else if(act==='back-list')navigate('home');return;}
  });
  document.getElementById('searchToggle').addEventListener('click',openSearch);
  document.getElementById('closeSearch').addEventListener('click',closeSearch);
  document.getElementById('searchInput').addEventListener('input',function(e){searchRender(e.target.value);});
  document.getElementById('settingsToggle').addEventListener('click',openSettings);
  document.getElementById('closeSettings').addEventListener('click',closeSettings);
  document.getElementById('saveCatalogUrl').addEventListener('click',saveRemoteCatalog);
  document.getElementById('resetCatalogUrl').addEventListener('click',function(){document.getElementById('catalogUrlInput').value='';saveRemoteCatalog();});
  document.getElementById('playerBack').addEventListener('click',stopPlayback);
  document.getElementById('catalogUrlInput').addEventListener('keydown',function(e){if(e.key==='Enter')saveRemoteCatalog();});
  window.addEventListener('load',function(){
    state.catalog = bundledCatalog();
    renderHome();
    var remote = '';
    try { remote = localStorage.getItem(sourceKey) || ''; } catch (e) {}
    if (!remote && window.CINE_CONFIG) remote = window.CINE_CONFIG.catalogUrl || '';
    if (remote) loadCatalog(remote).catch(function(err){ showToast('Catálogo local activo. No se pudo actualizar el catálogo remoto.'); });
    focusFirst();
  });
})();
