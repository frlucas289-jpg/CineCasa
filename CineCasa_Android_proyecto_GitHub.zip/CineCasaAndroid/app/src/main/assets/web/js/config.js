/* Configuración inicial. Déjalo vacío para usar app/data/catalog.json.
   También puedes poner aquí una URL HTTPS pública que entregue el JSON del catálogo. */
window.CINE_CONFIG = { catalogUrl: "" };
